import { useEffect, useState } from 'react';

const empty = { title: '', description: '', priority: 'Medium', status: 'Pending', dueDate: '' };

// Used for both CREATE (no "editing" task) and UPDATE (editing task passed in)
export default function TaskForm({ editing, onSave, onCancel }) {
  const [form, setForm] = useState(empty);

  useEffect(() => {
    setForm(editing ? { ...editing, dueDate: editing.dueDate ? editing.dueDate.slice(0, 10) : '' } : empty);
  }, [editing]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    onSave(form);
    if (!editing) setForm(empty);
  };

  return (
    <form className="card" onSubmit={submit}>
      <h3>{editing ? 'Edit task' : 'Add a new task'}</h3>
      <label>Title</label>
      <input required value={form.title} onChange={set('title')} placeholder="e.g. Finish React component" />
      <label>Description</label>
      <textarea rows="2" value={form.description} onChange={set('description')} />
      <div className="row">
        <div>
          <label>Priority</label>
          <select value={form.priority} onChange={set('priority')}>
            <option>Low</option><option>Medium</option><option>High</option>
          </select>
        </div>
        <div>
          <label>Status</label>
          <select value={form.status} onChange={set('status')}>
            <option>Pending</option><option>In Progress</option><option>Completed</option>
          </select>
        </div>
        <div>
          <label>Due date</label>
          <input type="date" value={form.dueDate} onChange={set('dueDate')} />
        </div>
      </div>
      <div className="actions">
        <button className="btn">{editing ? 'Update task' : 'Add task'}</button>
        {editing && <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
