const express = require('express');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

const router = express.Router();
router.use(auth); // every task route needs login

// READ: GET /api/tasks
router.get('/', async (req, res) => {
  const tasks = await Task.find({ user: req.userId }).sort({ createdAt: -1 });
  res.json(tasks);
});

// CREATE: POST /api/tasks
router.post('/', async (req, res) => {
  try {
    const { title, description, priority, status, dueDate } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ message: 'Title is required' });
    const task = await Task.create({ user: req.userId, title, description, priority, status, dueDate: dueDate || undefined });
    res.status(201).json(task);
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

// UPDATE: PUT /api/tasks/:id
router.put('/:id', async (req, res) => {
  try {
    const { title, description, priority, status, dueDate } = req.body;
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      { title, description, priority, status, dueDate: dueDate || null },
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json(task);
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

// DELETE: DELETE /api/tasks/:id
router.delete('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

module.exports = router;
